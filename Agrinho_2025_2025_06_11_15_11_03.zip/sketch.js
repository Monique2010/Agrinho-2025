let colheitadeira;
let espigasBoas = [];
let espigasEstragadas = [];
let pontuacao = 0;
let gameOver = false;
let tempoRestante = 90; // 90 segundos de jogo
let geracaoIntervalo = 60; // Gera novas espigas a cada 60 frames (1 segundo)

// Variáveis para imagens (opcional - altamente recomendado para este jogo!)
let imgColheitadeira;
let imgEspigaBoa;
let imgEspigaEstragada;
let imgFundoMilharal;

function preload() {
  // Descomente e substitua pelos caminhos das suas imagens.
  // Baixe ou crie imagens para:
  // - uma colheitadeira (imgColheitadeira.png)
  // - uma espiga de milho boa (imgEspigaBoa.png)
  // - uma espiga de milho estragada ou um toco (imgEspigaEstragada.png)
  // - um fundo que pareça um campo de milho (imgFundoMilharal.png)

  // imgColheitadeira = loadImage('assets/colheitadeira.png');
  // imgEspigaBoa = loadImage('assets/espiga_boa.png');
  // imgEspigaEstragada = loadImage('assets/espiga_estragada.png');
  // imgFundoMilharal = loadImage('assets/milharal_fundo.png');
}

function setup() {
  createCanvas(800, 600); // Tamanho ideal para um campo
  colheitadeira = new Colheitadeira();

  // Gera algumas espigas iniciais
  for (let i = 0; i < 7; i++) { // Mais espigas boas
    gerarEspigaBoa();
  }
  for (let i = 0; i < 3; i++) { // Algumas espigas estragadas/obstáculos
    gerarEspigaEstragada();
  }

  // Define um intervalo para o timer
  setInterval(contarTempo, 1000); // A cada 1 segundo
}

function draw() {
  if (gameOver) {
    background(50); // Fundo escuro para game over
    textAlign(CENTER);
    textSize(50);
    fill(255);
    text("Colheita Encerrada!", width / 2, height / 2 - 40);
    textSize(30);
    text("Milho Coletado: " + pontuacao, width / 2, height / 2 + 10);
    textSize(20);
    text("Pressione 'R' para Recomeçar", width / 2, height / 2 + 60);
    return;
  }

  // if (imgFundoMilharal) {
  //   image(imgFundoMilharal, 0, 0, width, height);
  // } else {
    background(100, 150, 50); // Cor de campo de milho
  // }

  // Desenha o limite superior da tela para simular o "fim" da plantação
  fill(0, 80, 0); // Verde escuro para o topo
  rect(0, 0, width, 50); // Faixa superior

  // Desenha e move a colheitadeira
  colheitadeira.show();
  colheitadeira.move();

  // Gera novas espigas periodicamente
  if (frameCount % geracaoIntervalo === 0) {
    if (random(1) < 0.8) { // 80% de chance de ser espiga boa
      gerarEspigaBoa();
    } else { // 20% de chance de ser espiga estragada
      gerarEspigaEstragada();
    }
  }

  // Desenha, move e verifica colisões das espigas boas
  for (let i = espigasBoas.length - 1; i >= 0; i--) {
    espigasBoas[i].show();
    espigasBoas[i].move();

    if (colheitadeira.colideCom(espigasBoas[i])) {
      pontuacao += 15; // Ganha mais pontos por milho
      espigasBoas.splice(i, 1);
    }

    if (espigasBoas[i].saiuDaTela()) {
      espigasBoas.splice(i, 1); // Remove se sair da tela
    }
  }

  // Desenha, move e verifica colisões das espigas estragadas
  for (let i = espigasEstragadas.length - 1; i >= 0; i--) {
    espigasEstragadas[i].show();
    espigasEstragadas[i].move();

    if (colheitadeira.colideCom(espigasEstragadas[i])) {
      pontuacao -= 10; // Perde pontos por milho estragado
      espigasEstragadas.splice(i, 1);
    }

    if (espigasEstragadas[i].saiuDaTela()) {
      espigasEstragadas.splice(i, 1); // Remove se sair da tela
    }
  }

  // Exibe a pontuação e o tempo
  fill(255); // Cor do texto branca
  textSize(24);
  text("Milho Coletado: " + pontuacao, 20, 30);
  text("Tempo: " + tempoRestante + "s", width - 150, 30);

  // Verifica se o tempo acabou
  if (tempoRestante <= 0) {
    gameOver = true;
  }
}

// Classe da Colheitadeira
class Colheitadeira {
  constructor() {
    this.width = 120;
    this.height = 80;
    this.x = width / 2 - this.width / 2;
    this.y = height - this.height - 30; // Perto da parte inferior
    this.speed = 8;
  }

  show() {
    // if (imgColheitadeira) {
    //   image(imgColheitadeira, this.x, this.y, this.width, this.height);
    // } else {
      fill(200, 150, 0); // Cor laranja/amarelada para a colheitadeira
      rect(this.x, this.y, this.width, this.height);
      fill(50); // Rodas
      rect(this.x + 10, this.y + this.height - 15, 25, 15);
      rect(this.x + this.width - 35, this.y + this.height - 15, 25, 15);
      fill(150, 100, 0); // Parte de cima
      rect(this.x + this.width / 4, this.y - 20, this.width / 2, 30);
    // }
  }

  move() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.speed;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.speed;
    }
    // Limita a colheitadeira na tela
    this.x = constrain(this.x, 0, width - this.width);
  }

  // Verifica colisão com outros objetos (baseado em retângulos)
  colideCom(objeto) {
    return (
      this.x < objeto.x + objeto.size &&
      this.x + this.width > objeto.x &&
      this.y < objeto.y + objeto.size &&
      this.y + this.height > objeto.y
    );
  }
}

// Classe da Espiga de Milho (base para boa e estragada)
class EspigaMilho {
  constructor(tipo) {
    this.size = 50; // Tamanho da espiga
    this.x = random(width - this.size);
    this.y = -this.size; // Começa acima da tela
    this.speed = random(2, 4); // Velocidade de "crescimento" ou queda
    this.tipo = tipo; // 'boa' ou 'estragada'
  }

  show() {
    if (this.tipo === 'boa') {
      // if (imgEspigaBoa) {
      //   image(imgEspigaBoa, this.x, this.y, this.size, this.size);
      // } else {
        fill(255, 200, 0); // Amarelo para espiga boa
        ellipse(this.x + this.size / 2, this.y + this.size / 2, this.size * 0.7, this.size); // Formato de espiga
        fill(0, 100, 0); // Casca verde
        rect(this.x + this.size / 4, this.y + this.size / 2, this.size / 2, this.size / 2);
      // }
    } else { // 'estragada'
      // if (imgEspigaEstragada) {
      //   image(imgEspigaEstragada, this.x, this.y, this.size, this.size);
      // } else {
        fill(100, 70, 0); // Marrom escuro para espiga estragada/toco
        rect(this.x + this.size / 4, this.y + this.size / 2, this.size / 2, this.size / 2); // Toco
        fill(50);
        ellipse(this.x + this.size / 2, this.y + this.size / 2, this.size * 0.7, this.size * 0.7); // Representa algo indesejado
      // }
    }
  }

  move() {
    this.y += this.speed;
  }

  saiuDaTela() {
    return this.y > height;
  }
}

// Funções para gerar espigas
function gerarEspigaBoa() {
  espigasBoas.push(new EspigaMilho('boa'));
}

function gerarEspigaEstragada() {
  espigasEstragadas.push(new EspigaMilho('estragada'));
}

// Função para o timer
function contarTempo() {
  if (!gameOver) {
    tempoRestante--;
  }
}

// Reiniciar o jogo ao pressionar 'R'
function keyPressed() {
  if (gameOver && (key === 'r' || key === 'R')) {
    resetGame();
  }
}

function resetGame() {
  pontuacao = 0;
  tempoRestante = 90;
  espigasBoas = [];
  espigasEstragadas = [];
  colheitadeira = new Colheitadeira();

  for (let i = 0; i < 7; i++) {
    gerarEspigaBoa();
  }
  for (let i = 0; i < 3; i++) {
    gerarEspigaEstragada();
  }
  gameOver = false;
}